package com.cg.demo.calculator;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.cg.demo.calculatorException.CalculatorException;

public class TestCases {
	CalculatorValidator valid = new CalculatorValidator();
	BasicCalculator cal = new BasicCalculator();
	
	BasicCalculator calculate =new BasicCalculator();
            
	        @Test
			public void numValidation() {
		    String num="111";
		    boolean actual = valid.validateNum(num);
		    boolean expected = true; 
		    
		    assertEquals(expected, actual);
	}
	        @Test
	        public void addValidation() throws CalculatorException {
	        int num1=100;
	        int num2=100;
			    int actual =cal.add(num1, num2);
			    int expected = 200; 
			    
			    assertEquals(expected, actual);
		}
	        @Test
	        public void subtractValidation() throws CalculatorException {
	        int num1=100;
	        int num2=100;
			    int actual =cal.subtract(num1, num2);
			    int expected = 0; 
			    
			    assertEquals(expected, actual);
		}
	        @Test
	        public void multiplyValidation() throws CalculatorException {
	        int num1=100;
	        int num2=100;
			    int actual =cal.multiply(num1, num2);
			    int expected = 10000; 
			    
			    assertEquals(expected, actual);
		}
	        
	        @Test
	        public void divideValidation() throws CalculatorException {
	        int num1=100;
	        int num2=100;
			    int actual =cal.divide(num1, num2);
			    int expected = 1; 
			    
			    assertEquals(expected, actual);
		}
	        
	        
	        
	        
}
