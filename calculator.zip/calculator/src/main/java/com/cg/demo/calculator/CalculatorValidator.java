package com.cg.demo.calculator;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CalculatorValidator {
   
	 public boolean validateNum(String num) {
		 if(num==null)
				throw new NullPointerException();
			Pattern pat=Pattern.compile("^[0-9]{1,9}");
			Matcher mat= pat.matcher(num);
			if(mat.matches())
				return true;
			else
				return false;
		}
}
