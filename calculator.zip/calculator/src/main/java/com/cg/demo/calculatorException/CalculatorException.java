package com.cg.demo.calculatorException;

public class CalculatorException extends Exception {

public CalculatorException() {
	
}

public CalculatorException(String s) {
	super(s);
}
}
