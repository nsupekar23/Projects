package com.cg.demo.calculator;

import java.util.Scanner;

import com.cg.demo.calculatorException.CalculatorException;

public class TestCalculator {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		BasicCalculator calculate = new BasicCalculator();
		CalculatorValidator validate = new CalculatorValidator();
		int option;
		String num1;
		String num2;
		int result;
		
		do {
			System.out.println("Enter option");
			System.out.println("1.Add");
			System.out.println("2.Subtract");
			System.out.println("3.Multiply");
			System.out.println("4.Division");
			System.out.println("5.Exit");
			option = sc.nextInt();
			
			switch(option) {
		   
			case 1:
			try {
			System.out.println("Enter First Number");
			num1 = sc.next();
			if(validate.validateNum(num1)==false)
				throw new CalculatorException("Please enter Number upto 9 digit;");
			
			System.out.println("Enter Second Number");
			num2 = sc.next();
			if(validate.validateNum(num2)==false)
				throw new CalculatorException("Please enter Number upto 9 digit;");
			
	
			result=calculate.add(Integer.parseInt(num1), Integer.parseInt(num2));

				System.out.println("Addition : "+result);
			} catch (CalculatorException e) {

				System.out.println(e.getMessage());
			}
			break;
			
			case 2:
				try {
				System.out.println("Enter First Number");
				num1 = sc.next();
				if(validate.validateNum(num1)==false)
					throw new CalculatorException("Please enter Number upto 9 digit;");
				
				System.out.println("Enter Second Number");
				num2 = sc.next();
				if(validate.validateNum(num2)==false)
					throw new CalculatorException("Please enter Number upto 9 digit;");
				
				
					result=calculate.subtract(Integer.parseInt(num1), Integer.parseInt(num2));
				
				System.out.println("Subtraction : "+result);
				} catch (CalculatorException e) {
					
					System.out.println(e.getMessage());
				}
		    break;
		    
			case 3:
				try {
					System.out.println("Enter First Number");
					num1 = sc.next();
					if(validate.validateNum(num1)==false)
						throw new CalculatorException("Please enter Number upto 9 digit;");
					
					System.out.println("Enter Second Number");
					num2 = sc.next();
					if(validate.validateNum(num1)==false)
						throw new CalculatorException("Please enter Number upto 9 digit;");
					
					result=calculate.subtract(Integer.parseInt(num1), Integer.parseInt(num2));
					System.out.println("Multiplication : "+result);
				} catch (CalculatorException e) {
				
					System.out.println(e.getMessage());
				}
		    break;
		    
			case 4:
				try {
					System.out.println("Enter First Number");
					num1 = sc.next();
					if(validate.validateNum(num1)==false)
						throw new CalculatorException("Please enter Number upto 9 digit;");
					
					System.out.println("Enter Second Number");
					num2 = sc.next();
					if(validate.validateNum(num1)==false)
						throw new CalculatorException("Please enter Number upto 9 digit;");
					
					result=calculate.subtract(Integer.parseInt(num1), Integer.parseInt(num2));
					System.out.println("Division : "+result);
				
				} catch (CalculatorException e) {
					System.out.println(e.getMessage());
				}
		    break;
			}
			
		} while (option!=5);
		
      sc.close();
	}

}
