package com.cg.payment.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.validator.constraints.NotEmpty;
@Entity
@Table(name = "customer")

public class Customer {
	@Id

	@Column(name = "accno")
	private long AcNO;
	@Column(name = "pin")
	private int pin;
	@NotEmpty(message="Required field")
	@Column(name = "name")
	private String name;

	public Customer(long AcNO, int pin, String name, long phone_number, String address, int balance) {
		this.AcNO = AcNO;
		this.pin = pin;
		this.name = name;
		this.phone_number = phone_number;
		this.address = address;
		this.balance = balance;
	}

	@Column(name = "phonenumber")
	private long phone_number;
	@Column(name = "address")
	private String address;
	@Column(name = "balance")
	private int balance;
	@Transient
	private int amount;
	@Transient
	private long AccountNumber;
	
	
	
	
	
	
	public long getAccountNumber() {
		return AccountNumber;
	}

	public void setAccountNumber(long accountNumber) {
		AccountNumber = accountNumber;
	}

	public int getAmount() {
		return amount;
	}

	public void setAmount(int amount) {
		this.amount = amount;
	}

	public long getAcNO() {
		return AcNO;
	}

	public void setAcNO(long acNO) {
		AcNO = acNO;
	}

	public int getPin() {
		return pin;
	}

	public void setPin(int pin) {
		this.pin = pin;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public long getPhone_number() {
		return phone_number;
	}

	public void setPhone_number(long phone_number) {
		this.phone_number = phone_number;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public int getBalance() {
		return balance;
	}

	public void setBalance(int balance) {
		this.balance = balance;
	}





	@Override
	public String toString() {
		return "Customer [AcNO=" + AcNO + ", pin=" + pin + ", name=" + name + ", phone_number=" + phone_number
				+ ", address=" + address + ", balance=" + balance + ", amount=" + amount + ", AccountNumber="
				+ AccountNumber + "]";
	}

	public Customer() {

	}

}
