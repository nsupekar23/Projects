package com.cg.payment.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "transaction")
public class Transaction 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="transactionid")
	private int transactionID;
	
	@Column(name="type", length=6)
	private String type;
	
	@Column(name="acno", length=10)
	private long acno;
	
	@Column(name="amount")
	private double amount;

	public double getTransactionID() {
		return transactionID;
	}

	public void setTransactionID(int d) {
		this.transactionID = d;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public long getAcno() {
		return acno;
	}

	public void setAcno(long acno2) {
		this.acno = acno2;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	@Override
	public String toString() {
		return "Transaction:\n Transaction ID=" + transactionID + "\n Type=" + type + "\n Account No=" + acno + "\n Amount="
				+ amount;
	}

}
