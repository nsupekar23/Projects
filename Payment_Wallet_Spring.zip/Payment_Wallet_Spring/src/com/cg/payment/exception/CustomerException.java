package com.cg.payment.exception;

public class CustomerException extends Exception {
	public CustomerException(){
		
	}
	public CustomerException(String s ) {
		super(s);
	}
}
