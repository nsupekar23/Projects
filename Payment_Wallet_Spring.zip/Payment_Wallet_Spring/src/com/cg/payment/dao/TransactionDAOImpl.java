package com.cg.payment.dao;


import java.util.ArrayList;


import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.payment.bean.Customer;
import com.cg.payment.bean.Transaction;
import com.cg.payment.exception.CustomerException;


@Repository
@Transactional
public class TransactionDAOImpl implements iTransactionDAO {
	@PersistenceContext
	EntityManager em = null;

	@Override
	public Transaction addtransaction(Transaction trans) throws CustomerException {
		// TODO Auto-generated method stub

		em.persist(trans);

		return trans;
	}

	@Override
	public ArrayList<Transaction> gettransaction(long acno) throws CustomerException {

		// TODO Auto-generated method stub
		TypedQuery tq = em.createQuery("Select tran from Transaction tran where acno='" + acno + "'",
				Transaction.class);
		ArrayList cusList = (ArrayList) tq.getResultList();
		return cusList;
	}
}