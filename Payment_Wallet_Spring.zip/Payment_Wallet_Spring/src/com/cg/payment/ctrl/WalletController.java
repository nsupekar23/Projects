package com.cg.payment.ctrl;

import java.util.ArrayList;


import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.payment.bean.Customer;
import com.cg.payment.bean.Transaction;
import com.cg.payment.exception.CustomerException;
import com.cg.payment.service.iCustomerService;
import com.cg.payment.service.iTransaction;


@Controller
public class WalletController {

@Autowired
	iCustomerService cusSer=null;


@Autowired
iTransaction cusSer1 = null;

	public iCustomerService getLogSer() {
		return cusSer;
	}

	public void setLogSer(iCustomerService cusSer) {
		this.cusSer = cusSer;
	}
	
	public iTransaction getCusSer1() {
		return cusSer1;
	}

	public void setCusSer1(iTransaction cusSer1) {
		this.cusSer1 = cusSer1;
	}

	
	/************* Displaying Home Page *************/
	
	@RequestMapping(value="/ShowHomePage" ,method=RequestMethod.GET)
	public String dispHomePage(Model model)
	{
		Customer cus=new Customer();
		
		model.addAttribute("loginObj",cus);
		return "Login";
	}
	
	
	
	/** *********************Login Valid User******************************/
	

@RequestMapping(value="/validateUser",method=RequestMethod.POST)
	public String isUserValid(@ModelAttribute("userObj")@Valid Customer cus,BindingResult result,Model model) 
	{
	
	try {
		Customer cust1=cusSer.getAccount(cus.getAcNO());
		if(cust1== null){
			String reg="Please Register yourself";
			model.addAttribute("msgObj",reg);
			return "NewAccount";
			}
else {
			if(cust1.getPin()==cus.getPin()) {
				String msg="Welcome  "+cust1.getName()+"("+cust1.getAcNO()+")";
				model.addAttribute("deposite",msg);
				model.addAttribute("account",cus.getAcNO());
			
				return "Menu";
			}else {
				String msg ="please enter valid password";
				model.addAttribute("msgObj",msg);
				return "Login";
			}}
		}catch (CustomerException e) {
			
			e.printStackTrace();
		}
	
		return "NewAccount";
	
		}	
			


	/************  Displaying Register Page  ***********/


	@RequestMapping(value="/RegisterPage")
	public String dispRegisterPage(Model model)
	{
		Customer cus=new Customer();
		model.addAttribute("userObj",cus);
		
		return "NewAccount";
	}



	 /************************Creating New Account****************/
	
		@RequestMapping(value="/newAccount")
		public String createAccount(@ModelAttribute("userObj") Customer cust1, Model model) {
			try {
		Customer cus1=cusSer.createAccount(cust1);
		String msg="Welcome "+cus1.getName();
		model.addAttribute("account",cus1.getAcNO());
		model.addAttribute("deposite",msg);
		model.addAttribute("name",cus1.getName());
			}catch (CustomerException e) {
			
				e.printStackTrace();
			}
			return "Menu";
			
		}
		
		
		
	/*******************Add Money *******************************/
		
		@RequestMapping(value="/addLink")
		public String addMoney(@RequestParam("acno") Long ac,Model model) 
		{
			try {
				Customer cust=cusSer.getAccount(ac);
				model.addAttribute("account",cust.getAcNO());
				model.addAttribute("name",cust.getName());
				model.addAttribute("balance",cust.getBalance());
				model.addAttribute("userObj",cust);
			}catch(CustomerException e)
			{
				e.printStackTrace();
			}
			return "AddMoney";
		}
	
		/*****************Withdraw Money*************************/
		
		@RequestMapping(value="/withdrawLink")
		public String WithdrawMoney(@RequestParam("acno")Long ac,Model model) {

			try {
				Customer cust = cusSer.getAccount(ac);
				model.addAttribute("accountid",cust.getAcNO());
				model.addAttribute("name",cust.getName());
				model.addAttribute("balance",cust.getBalance());
				model.addAttribute("userObj",cust);
				
			} catch (CustomerException e) {
		
				e.printStackTrace();
			}

			return "WithdrawMoney";
		}

		
		
		/*********************** Showing Balance***********************/
		
		
		@RequestMapping(value="/showBalanceLink")
		public String ShowBalance(@RequestParam("acno")Long ac,Model model) {
			try {
				Customer cust = cusSer.getAccount(ac);
				model.addAttribute("userObj",cust);
				String msg = "Your account balance is "+cust.getBalance();
				model.addAttribute("balance",msg);
				
			} catch (CustomerException e) {
				
				e.printStackTrace();
			}
		
			return "Balance";
		}
		
		/***********************  Transactions***********************/

		
		@RequestMapping(value="/transactions")
		public String displayTransactions(Model model) {
			Customer cust = new Customer();
			model.addAttribute("userObj",cust);
			model.addAttribute("account",cust.getAcNO());
			
			
			return "Transactions";
		}
		
		
		/******************* Transferring Money To Another Account***********************/

		@RequestMapping(value="/fundTransferLink")
		public String TransferMoney(@RequestParam("acno")Long ac,Model model) {

			try {
				Customer cust = cusSer.getAccount(ac);
				model.addAttribute("userObj",cust);
				
			} catch (CustomerException e) {
				
				e.printStackTrace();
			}
		
			
			return "TransferMoney";
		}
		
		/*****************************Transaction Details**********************************/
		
		@RequestMapping(value="/transactionLink")
		public String Transactions(@RequestParam("acno")Long id,Model model) {

			try {
				ArrayList<Transaction> clist = cusSer1.gettransaction(id);
				model.addAttribute("list",clist);
				
			} catch (CustomerException e) {
			
				e.printStackTrace();
			}
		
			
			return "Transaction";
		}
		
		/**********************************LogOut***************************************/
		
		@RequestMapping(value="/logOut")
		public String LogOut() {
	
			return "redirect:/ShowHomePage.obj";
			}
	}
