package com.cg.payment.ctrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;


import com.cg.payment.bean.Customer;
import com.cg.payment.bean.Transaction;
import com.cg.payment.exception.CustomerException;
import com.cg.payment.service.iCustomerService;
import com.cg.payment.service.iTransaction;


@Controller
public class OperationContoller {
	
	@Autowired
	iCustomerService cusSer=null;

	@Autowired
	iTransaction cusSer1 = null;


	

	public iCustomerService getCusSer() {
		return cusSer;
	}

	public void setCusSer(iCustomerService cusSer) {
		this.cusSer = cusSer;
	}

	public iTransaction getCusSer1() {
		return cusSer1;
	}

	public void setCusSer1(iTransaction cusSer1) {
		this.cusSer1 = cusSer1;
	}

	/*******************After Adding Money *************************/
	
	
	@RequestMapping(value="/adding")
	public String addingMoney(@ModelAttribute("userObj") Customer cus,Model model) 
	{
		try {
			Customer cust=cusSer.AddMoney(cus.getAcNO(), cus.getPin(), cus.getAmount());
			Transaction tran=new Transaction();
			tran.setAcno(cus.getAcNO());
			tran.setAmount(cus.getAmount()); 
			tran.setType("Deposite");
			cusSer1.addtransaction(tran);
			String deposite="Amount Added Successfully";
			model.addAttribute("deposite",deposite);
			model.addAttribute("account",cus.getAcNO());
		}catch (CustomerException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "Menu";
	}
	
	/*********************Withdrawing Money *********************/
	
	@RequestMapping(value = "/withdraw")
	public String withDraw(@ModelAttribute("userObj") Customer cus, BindingResult result, Model model) {
		try {
			Customer cust =cusSer.withdraw(cus.getAcNO(), cus.getAmount());
			System.out.println(cust);
			String deposit=" Amount withdraw Successful";
			model.addAttribute("deposit",deposit);
			Transaction trans1 = new Transaction();
			model.addAttribute("account",cust.getAcNO());
			trans1.setAcno(cust.getAcNO());
			trans1.setAmount(cus.getAmount());
			trans1.setType("Withdraw");
			cusSer1.addtransaction(trans1);
		} catch (CustomerException e) {
			// TODO Auto-generated catch block
			System.out.println(e.getMessage());
		}
		return "Menu";
	}
	
	
	/**********************Amount Transferring****************/
	
	@RequestMapping(value = "/transferMoney")
	public String Transfer(@ModelAttribute("userObj") Customer cus, BindingResult result, Model model) {
		try {
			Transaction trans2 = new Transaction();
			System.out.println(cus);
			Customer cust =cusSer.TransferMoney(cus.getAcNO(), cus.getAccountNumber(), cus.getAmount());
			System.out.println(cust);
			String deposit=" Amount Transfer Successful";
			model.addAttribute("deposit",deposit);
			model.addAttribute("account",cus.getAcNO());
			trans2.setAcno(cus.getAcNO());
			trans2.setAmount(cus.getAmount());
			trans2.setType("Transfer");
			cusSer1.addtransaction(trans2);
		} catch (CustomerException e) {
		
			System.out.println(e.getMessage());
		}
		return "Menu";
	}
}
