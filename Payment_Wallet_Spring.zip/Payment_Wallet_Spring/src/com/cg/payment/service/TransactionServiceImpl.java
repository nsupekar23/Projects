package com.cg.payment.service;

import java.util.ArrayList;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.payment.bean.Transaction;

import com.cg.payment.dao.iTransactionDAO;
import com.cg.payment.exception.CustomerException;

@Service
@Transactional
public class TransactionServiceImpl implements iTransaction {
	@Autowired
	iTransactionDAO dao = null;


	public iTransactionDAO getDao() {
		return dao;
	}

	public void setDao(iTransactionDAO dao) {
		this.dao = dao;
	}

	@Override
	public Transaction addtransaction(Transaction trans) throws CustomerException {
		// TODO Auto-generated method stub
		return dao.addtransaction(trans);
	}

	@Override
	public ArrayList<Transaction> gettransaction(long acno) throws CustomerException {
		// TODO Auto-generated method stub
		return dao.gettransaction(acno);
	}



}
