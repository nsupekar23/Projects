package com.cg.payment.service;

import java.util.ArrayList;

import com.cg.payment.bean.Transaction;
import com.cg.payment.exception.CustomerException;

public interface iTransaction {
	public Transaction addtransaction(Transaction trans) throws CustomerException;
	public ArrayList<Transaction> gettransaction(long acno) throws CustomerException ;
}

