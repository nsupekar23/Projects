package com.cg.paymentwallet.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import com.cg.paymentwallet.bean.Transaction;
import com.cg.paymentwallet.exception.CustomerException;
import com.cg.paymentwallet.util.DButil;

public class TransactionDAOImpl implements iTransactionDAO {
	Connection conn = null;

	@Override
	public Transaction addtransaction(Transaction trans) throws CustomerException {
		// TODO Auto-generated method stub
		conn = DButil.getConnection();

		try {
			PreparedStatement pst = conn.prepareStatement("INSERT INTO transaction VALUES(?,?,?,?)");
			pst.setDouble(1, trans.getTransactionID());
			pst.setString(2, trans.getType());
			pst.setLong(3, trans.getAcno());
			pst.setInt(4, trans.getAmount());
			pst.executeUpdate();
		} catch (SQLException e) {
			throw new CustomerException("Problem in Transaction details" + e.getMessage());
		}
		return trans;
	}

	@Override
	public ArrayList<Transaction> gettransaction() throws CustomerException {
		// TODO Auto-generated method stub

		ArrayList<Transaction> arr = new ArrayList<>();
		conn = DButil.getConnection();
		try {
			Statement st = conn.createStatement();
			ResultSet rst = st.executeQuery("select transactionid,type,acno,amount from transaction");
			while (rst.next()) {
				Transaction trans = new Transaction();
				trans.setAcno(rst.getLong("acno"));
				trans.setAmount(rst.getInt("amount"));
				trans.setTransactionID(rst.getInt("transactionid"));
				trans.setType(rst.getString("type"));
				arr.add(trans);
			}
		} catch (Exception e) {
			System.out.println(e.getMessage());
		}
		return arr;

	}

}