import java.util.Scanner;
public class CheckNumber
{
	public static boolean checkNum(int n)
	{
	if (n==0)
	{
	return false;
	}
	while(n!=1)
	{
	n=n/2;
	if(n%2!=0 && n!=1)
	{
	return false;
	}
	}
	return true;
	}
public static void main(String args[])
{
	//int n = 12;
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the number of values= ");
	int n=sc.nextInt();
	if(checkNum(n)==false)
	{
		System.out.println("Number " +n + " is not the power of 2");
	}
	else
	{ 
		System.out.println("Number " +n + " is the power of 2");
	}
}
}
/*public static void main(String[] args)
{
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the number of values= ");
	int n=sc.nextInt();
	CheckNumber obj= new CheckNumber();
	obj.checkNum(n);
}
}*/