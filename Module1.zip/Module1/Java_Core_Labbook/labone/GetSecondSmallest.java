import java.util.Scanner;
public class GetSecondSmallest
{
	public static void getSecondSmallest(int[] arr){
		int n = l;
		int temp=0