//Create a class with a method which can calculate the sum of first n natural numbers which are divisible by 3 or 5.

import java.util.Scanner;
public class CalculateSum
{
	int sum=0;
	int i;
	public void calculateSum(int n)
	{
		for(i=0;i<=n;i++)
		{
		if(i % 3==0 || i % 5==0)
			{
			sum=sum+i;
			}
		}
	System.out.println("sum is= "+sum);
	}
public static void main(String[] args)
{
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the number of values= ");
	int n=sc.nextInt();
	CalculateSum obj= new CalculateSum();
	obj.calculateSum(n);
}
}
