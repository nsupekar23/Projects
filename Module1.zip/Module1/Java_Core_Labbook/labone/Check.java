//Create a method to check if a number is an increasing number

import java.util.Scanner;
public class Check
{
	public static boolean checkNum(int n)
	{
	int a=n%10;
	n=n/10;
	while(n>0)
	{
		if(a<n%10)
		{
			return false;
		}
		a=n%10;
		n=n/10;
	}
	return true;
	}
public static void main(String args[])
{
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the number of values= ");
	int n=sc.nextInt();
	if(checkNum(n)==false)
	{
		System.out.println("Number " +n + " is not increasing");
	}
	else
	{ 
		System.out.println("Number " +n + " is increasing");
	}
}
}