//Create a class with a method to find the difference between the sum of the squares and the square of the sum of the first n natural numbers.

import java.util.Scanner;
public class CalculateDifference
{
	int sum1=0;
	int sum2=0;
	int sum3=0;
	int i,d;
	public void calculateDifference(int n)
	{
		for(i=1;i<=n;i++)
		{
			sum1=sum1+(i*i);
		}
		for(i=1;i<=n;i++)
		{
			sum2=sum2+i;
			sum3=sum2*sum2;
		}
	  d = sum3 - sum1;
	System.out.println("Difference is= "+d);
	}
public static void main(String[] args)
{
	Scanner sc= new Scanner(System.in);
	System.out.println("Enter the number of values= ");
	int n=sc.nextInt();
	CalculateDifference obj= new CalculateDifference();
	obj.calculateDifference(n);
}
}
