package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.bean.Author;


public interface IAuthorService 
{
	public Author addAuthor(Author ee);
	public Author getAuthorById(int authId);
	public Author deleteAuthorById(int authId);
	
	public Author updatePhnNo(int authId, long PhnNo);
}
