package com.cg.demo.dao;

import java.util.ArrayList;

import com.cg.demo.bean.Author;


public interface IAuthorDao {
	
public Author addAuthor(Author ath);
public Author getAuthorById(int authId);


public Author deleteAuthorById(int authId);

 
public Author updatePhnNo(int authId,long phnNo);

}

