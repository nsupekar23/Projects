package com.cg.demo.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="author_master")

public class Author 
{
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="author_id",length=10)
private int authorId;
	@Column(name="author_fname",length=20)	
private String firstName;
	@Column(name="author_mname",length=10)
private String middleName;
	@Column(name="author_lname",length=20)
private String lastName;
	@Column(name="author_phn",length=15
			)	
private long phnNo;
public int getAuthorId() {
	return authorId;
}
public void setAuthorId(int authorId) {
	this.authorId = authorId;
}
public String getFirstName() {
	return firstName;
}
public void setFirstName(String firstName) {
	this.firstName = firstName;
}
public String getMiddleName() {
	return middleName;
}
public void setMiddleName(String middleName) {
	this.middleName = middleName;
}
public String getLastName() {
	return lastName;
}
public void setLastName(String lastName) {
	this.lastName = lastName;
}

public long getPhnNo() {
	return phnNo;
}
public void setPhnNo(long phnNo) {
	this.phnNo = phnNo;
}
public Author(int authorId, String firstName, String middleName, String lastName, long phnNo) {
	super();
	this.authorId = authorId;
	this.firstName = firstName;
	this.middleName = middleName;
	this.lastName = lastName;
	this.phnNo = phnNo;
}
public Author() {
	super();
	// TODO Auto-generated constructor stub
}
@Override
public String toString() {
	return "Author [authorId=" + authorId + ", firstName=" + firstName + ", middleName=" + middleName + ", lastName="
			+ lastName + ", phnNo=" + phnNo + "]";
}





}
