package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.bean.Author;

import com.cg.demo.dao.AuthorDaoImpl;
import com.cg.demo.dao.IAuthorDao;

public class AuthorServiceImpl implements IAuthorService 
{
IAuthorDao authDao=null; 
public AuthorServiceImpl()
{
	authDao= new AuthorDaoImpl();
	
}
	public Author addAuthor(Author ee) {
		
		return authDao.addAuthor(ee);
	}

	public Author getAuthorById(int authId) {
	
		return authDao.getAuthorById(authId);
	}
	public Author deleteAuthorById(int authId) {
		return authDao.deleteAuthorById(authId);
	}
	
	 
	public Author updatePhnNo(int authId, long PhnNo) {
		
		
	return 	authDao.updatePhnNo(authId, PhnNo);
		
	}
}
