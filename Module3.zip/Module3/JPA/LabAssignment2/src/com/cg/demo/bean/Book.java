package com.cg.demo.bean;

public class Book {

}
