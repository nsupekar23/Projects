package com.cg.demo.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;

import com.cg.demo.bean.Author;
import com.cg.demo.util.JPAUtil;

public class BookAuthorDaoImpl implements IBookAuthorDao 
	{
		EntityManager em= null;
		EntityTransaction tran=null;
		public BookAuthorDaoImpl()
		{
		}
		

	@Override
	public Author addAuthor(Author auth) 
	{
		
		em= JPAUtil.getEntityManager();
		tran  = em.getTransaction();
		tran.begin();
		em.persist(auth);
		tran.commit();
		System.out.println("Data is inserted in the table");
		Author a1= em.find(Author.class, auth.getAuthorId());
		return a1;
	
		
	}

	@Override
	public Author getAuthorById(int authId) {
		em= JPAUtil.getEntityManager();
		Author e1= em.find(Author.class, authId);
		
		return e1;
	}

	@Override
	public Author deleteAuthorById(int authId) {
		em= JPAUtil.getEntityManager();
		Author ee= em.find(Author.class, authId);
		
		tran=em.getTransaction();
		tran.begin();
		em.remove(ee);
		tran.commit();
		
		return ee;
	}

	public Author updatePhnNo(int authId, long phnNo) {

		long updatedPhn;
		em= JPAUtil.getEntityManager();
		tran=em.getTransaction();
		
		Author auth1= em.find(Author.class, authId);
		updatedPhn = phnNo;
		auth1.setPhnNo(updatedPhn);
		tran.begin();
		em.merge(auth1);
		tran.commit();
		System.out.println("Phn Number is updated for:"+authId);
		
		return auth1;
	}
	

}
