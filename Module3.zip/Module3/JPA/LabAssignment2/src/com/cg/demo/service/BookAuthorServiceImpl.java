package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.bean.Author;

import com.cg.demo.dao.BookAuthorDaoImpl;
import com.cg.demo.dao.IBookAuthorDao;

public class BookAuthorServiceImpl implements IBookAuthorService 
{
IBookAuthorDao authDao=null; 
public BookAuthorServiceImpl()
{
	authDao= new BookAuthorDaoImpl();
	
}
	public Author addAuthor(Author ee) {
		
		return authDao.addAuthor(ee);
	}

	public Author getAuthorById(int authId) {
	
		return authDao.getAuthorById(authId);
	}
	public Author deleteAuthorById(int authId) {
		return authDao.deleteAuthorById(authId);
	}
	
	 
	public Author updatePhnNo(int authId, long PhnNo) {
		
		
	return 	authDao.updatePhnNo(authId, PhnNo);
		
	}
}
