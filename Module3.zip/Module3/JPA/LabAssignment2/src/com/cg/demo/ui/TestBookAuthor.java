package com.cg.demo.ui;



import java.util.Date;
import java.util.Scanner;

import com.cg.demo.bean.Author;

import com.cg.demo.service.BookAuthorServiceImpl;

import com.cg.demo.service.IBookAuthorService;



public class TestBookAuthor {
	
	public static void main(String[] args) 
	{
		
		Scanner sc= new Scanner(System.in);
		IBookAuthorService authSer= new BookAuthorServiceImpl();
		int opt,id;
		do {
			Author a1 = new Author();
		

		System.out.println("1.Add the Employee ");
		System.out.println("2.Delete the Employee ");
		System.out.println("3.Display the Employee");
		System.out.println("4.Update the Employee");
		System.out.println("5.Exit");
		System.out.println("Enter Your Options: ");
		opt= sc.nextInt();
		switch(opt) {
		case 1 :
		;
		System.out.println("Enter First Name: ");
		String fname= sc.next();
		System.out.println("Enter Middle Name: ");
		String mname= sc.next();
		System.out.println("Enter Last Name: ");
		String lname= sc.next();
		System.out.println("Enter Phone Number: ");
		long phnNo= sc.nextLong();
		
		a1.setFirstName(fname);
		a1.setMiddleName(mname);
		a1.setLastName(lname);
		a1.setPhnNo(phnNo);
		
		authSer.addAuthor(a1);
		
		break;
		case 2:
		System.out.println("Enter Author id ");
		id= sc.nextInt();
		Author ee2=authSer.deleteAuthorById(id);
		System.out.println(ee2.getAuthorId()+" is deleted from the table");
		break;
		case 3:
		System.out.println("Enter Author id");
		id=sc.nextInt();
		Author ee=authSer.getAuthorById(id);
		System.out.println(ee);
		break;
		case 4:
			System.out.println("Enter Author id");
			id=sc.nextInt();
			System.out.println("Enter your new Phone Number");
			long newPhnNo=sc.nextLong();
			Author ee3 = authSer.updatePhnNo(id,newPhnNo);

			System.out.println("Updated Number:"+ee3);
			break;
		case 5:
		System.exit(0);
		}
		}while(opt!=6);
		
	}
}
		