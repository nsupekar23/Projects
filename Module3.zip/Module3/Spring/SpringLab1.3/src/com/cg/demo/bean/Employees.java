package com.cg.demo.bean;

public class Employees {
	
	private int empsId;
	private String empsName;
	private double empsSal;
	
	
	@Override
	public String toString() {
		return "Employees [empsId=" + empsId + ", empsName=" + empsName + ", empsSal=" + empsSal + "]";
	}
	public int getEmpsId() {
		return empsId;
	}
	public void setEmpsId(int empsId) {
		this.empsId = empsId;
	}
	public String getEmpsName() {
		return empsName;
	}
	public void setEmpsName(String empsName) {
		this.empsName = empsName;
	}
	public double getEmpsSal() {
		return empsSal;
	}
	public void setEmpsSal(double empsSal) {
		this.empsSal = empsSal;
	}
	public Employees() {
		super();
	}
}
