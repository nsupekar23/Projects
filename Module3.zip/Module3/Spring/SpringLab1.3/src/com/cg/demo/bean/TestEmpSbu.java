package com.cg.demo.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmpSbu {

	public static void main(String[] args) {
		ApplicationContext ctx=new
				ClassPathXmlApplicationContext("cg.xml");
		SBU e1=(SBU)ctx.getBean("sbuAdd1");
		System.out.println(e1);


	}

}
