package com.cg.demo.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.demo.dao.ILoginDao;
import com.cg.demo.dto.Login;

import com.cg.demo.dto.Trainee;

@Service
public class LoginServiceImpl implements ILoginService
{

@Autowired
	ILoginDao loginDao= null;	
	public ILoginDao getLoginDao()
	{
		return loginDao;
	}

	public void setLoginDao(ILoginDao loginDao) 
	{
	this.loginDao = loginDao;
	}

	@Override
	public Login validateUser(Login user) 
	{
		return loginDao.validateUser(user);
	}

	@Override
	public Trainee addUserDetails(Trainee reg) {
		
		return loginDao.addUserDetails(reg);
	}



	@Override
	public ArrayList<Trainee> fetchAllUser() {
		
		return loginDao.fetchAllUser();
	}

	@Override
	public Trainee fetchById(int gettId) {
	
		return loginDao.fetchById(gettId);
	}

	
		@Override
		public void delById(Integer idd) {
			loginDao.delById(idd);
			
		}

	

		@Override
		public Trainee modifyById(Integer id, String nm, String doma, String locatn) {
		
			return loginDao.modifyById(id, nm, doma, locatn);
		}
	


}
