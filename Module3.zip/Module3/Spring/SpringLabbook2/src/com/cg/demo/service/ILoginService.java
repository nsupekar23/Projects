package com.cg.demo.service;

import java.util.ArrayList;

import com.cg.demo.dto.Login;
import com.cg.demo.dto.Trainee;


public interface ILoginService {
	
	public Login validateUser(Login user) ;
	public Trainee addUserDetails(Trainee reg);
//	public Login addUser(Login log);
	public void delById(Integer idd);
	public ArrayList<Trainee> fetchAllUser();
	public Trainee fetchById(int gettId);
	public Trainee modifyById(Integer id,String nm,String doma,String locatn);
	

}
