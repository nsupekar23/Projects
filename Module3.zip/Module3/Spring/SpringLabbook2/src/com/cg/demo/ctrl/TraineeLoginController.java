package com.cg.demo.ctrl;


import java.util.ArrayList;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.demo.dto.Login;

import com.cg.demo.dto.Trainee;
import com.cg.demo.service.ILoginService;

@Controller             //method level annotation
//@RequestMapping("/loginctrl")    //class level annotation
public class TraineeLoginController {


	@Autowired
	ILoginService logSer=null;
	
	public ILoginService getLogSer() {
		return logSer;
	}

	public void setLogSer(ILoginService logSer) {
		this.logSer = logSer;
	}

	@RequestMapping(value="/ShowLoginPage",
			method=RequestMethod.GET)
	
	public String dispLoginPage(Model model)
	{
		Login lg=new Login();
		model.addAttribute("loginObj",lg);
		return "Login";
	}
	/*********************************************/
	
	@RequestMapping(value="/ValidateUser",
			method=RequestMethod.POST)
	public String isUserValid(@ModelAttribute("loginObj")
		@Valid Login lgg,
		BindingResult result,Model model) 
	{
		if(result.hasErrors())
		{
			return "Login";
		}
		else
		{
			
		
			Login user=logSer.validateUser(lgg);
		
			if(user!=null)
			{
			if(user.getPassword().equalsIgnoreCase(lgg.getPassword()))
			{
				String msg="Trainee Management System:"+user.getUsername();
				model.addAttribute("MsgObj",msg);
				return "NewRegister";
			}
			else 
			{
				String msg="Sorry invalid password:" +user.getUsername();
				model.addAttribute("MsgObj",msg);
				return "Login";
			}
			}
		else
		{
			
	
			return "NewRegister";
		}
		}	}
	
	/*************************************************************/
	
	@RequestMapping("/GoBackLink")

	public String GobackLoginPage() {
	return "NewRegister";
	}

	/***************************************/
	@RequestMapping(value="/AddTraineeDetails")
	public String addUserDetails(@ModelAttribute("userObj") Trainee reg,
			Model model,
			BindingResult result)
		{
		
			Trainee reg1=new Trainee();
		
	
		model.addAttribute("userObj",reg1);
		ArrayList<String> domList=new ArrayList<String>();
		domList.add("Java");
		domList.add("Html");
		domList.add("JS");
		domList.add("Spring");
		model.addAttribute("dList",domList);
		
		return "AddTrainee";
		}
/***********************************************/
	
	@RequestMapping(value="/ShowAddedTrainee")
	
	public String dispAddedTrainee(@ModelAttribute("userObj") Trainee reg ,Model model,BindingResult result)
	{
		model.addAttribute("gfhb", reg);
		logSer.addUserDetails(reg);
		
		return "Success";
	}
	
	
	/***********************************************/
	@RequestMapping(value="/DeleteTrainee")
	public String DeleteTrainee(Model model)
	{
		Trainee tr=new Trainee();
		model.addAttribute("deleteObj",tr);
		return "DeleteTrainee";
	}
	

	/*****************************************/
	
	@RequestMapping("/ShowAllUserDetails")
	public String dispAlluserDetails(Model model)
	{
		ArrayList<Trainee> uList=logSer.fetchAllUser();
		model.addAttribute("UserListObj", uList);
		return "ListAllTrainee";
	}
	
	
	/***********************************************************/
	
	@RequestMapping(value="/ShowDeletDataPage")
	public String deleteDetail(@ModelAttribute("deleteObj") Trainee tr1,
			Model model)
	{
		Trainee trg=logSer.fetchById(tr1.gettId());
		model.addAttribute("TrgDetailObj", trg);
		
		return "InfoTrainee";
	}
	
	/************************************************************/
	
	@RequestMapping(value="/DeleteUserById")
	public String delById(@RequestParam("tid") Integer idd) {
	logSer.delById(idd);
	return "Success";
	}
	
	/******************************************************/
	@RequestMapping(value="/ShowUserById")
	public String RetriveTrainee(Model model)
	{
		Trainee tr=new Trainee();
		model.addAttribute("retriveObj",tr);
		return "RetriveTrainee";
		
	}
	
	
	/*******************************************************/
	@RequestMapping(value="/ShowRetrDataPage")
	public String retriveDetail(@ModelAttribute("retriveObj") Trainee tr1,
			Model model)
	{
		Trainee trg=logSer.fetchById(tr1.gettId());
		model.addAttribute("TrgDetailObj", trg);
		
		return "RetriveInfojsp";
	}
	
	/**********************************************************/
	@RequestMapping(value="/ModifyTrainee")
	public String ModifyTrainee(Model model)
	{
		Trainee tr=new Trainee();
		model.addAttribute("modifyObj",tr);
		return "ModifyTrainee";
	}
	
	/**************************************************************/
	
	@RequestMapping(value="/ShowModifyDataPage")
	public String modifyDetail(@ModelAttribute("modifyObj") Trainee tr1,
			Model model)
	{
		Trainee trg=logSer.fetchById(tr1.gettId());   
		model.addAttribute("modifyObj", trg);
		
		return "ModifyInfo";
	}
/************************************************************/
	
	@RequestMapping(value="/ShowModifyInput")
	public String modifyById(@ModelAttribute("modifyObj") Trainee tr1,Model model) {
		int i=tr1.gettId();
		String j=tr1.getTname();
		String k=tr1.getTdom();
		String l=tr1.getTloc();
	logSer.modifyById(i,j,k,l);
	return "Success";
	}
	
	
}