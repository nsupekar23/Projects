package com.cg.demo.dao;

import java.util.ArrayList;

import com.cg.demo.dto.Login;

import com.cg.demo.dto.Trainee;

public interface ILoginDao {
	
	public Login validateUser(Login user) ;
	public Trainee addUserDetails(Trainee reg);
//	public Login addUser(Login log);
	
	public ArrayList<Trainee> fetchAllUser();
	public Trainee fetchById(int gettId);
	public void delById(Integer idd);
	
	public Trainee modifyById(Integer id,String nm,String doma,String locatn);
}
