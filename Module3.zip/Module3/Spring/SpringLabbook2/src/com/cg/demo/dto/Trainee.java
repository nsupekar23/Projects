package com.cg.demo.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


	@Entity
	@Table(name="trainee_details")
	public class Trainee {
		
		@Id
		@Column(name="trainee_id")
		private int tId;
		
		@Column(name="trainee_name")
		private String tname;
		
		@Column(name="trainee_domain")
		private String tdom;
		
		@Column(name="trainee_location")
		private String tloc;
		public Trainee(int tId, String pwd, String tname, String tdom, String tloc) {
			super();
			this.tId = tId;
			this.tname = tname;
			this.tdom = tdom;
			this.tloc = tloc;
		}

		

		@Override
		public String toString() {
			return "Trainee [tId=" + tId + ", tname=" + tname + ", tdom=" + tdom + ", tloc=" + tloc + "]";
		}



		public Trainee() {
			super();
		}

		public int gettId() {
			return tId;
		}

		public void settId(int tId) {
			this.tId = tId;
		}

	

		public String getTname() {
			return tname;
		}

		public void setTname(String tname) {
			this.tname = tname;
		}

		public String getTdom() {
			return tdom;
		}

		public void setTdom(String tdom) {
			this.tdom = tdom;
		}

		public String getTloc() {
			return tloc;
		}

		public void setTloc(String tloc) {
			this.tloc = tloc;
		}

	}


