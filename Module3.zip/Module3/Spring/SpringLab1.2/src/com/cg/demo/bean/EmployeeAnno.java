package com.cg.demo.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component("emp1")
public class EmployeeAnno {
	
	@Value("12345")
	private int empsId;
	
	@Value("Harriet")
	private String empsName;
	
	@Value("40000.0")
	private double empsSal;
	
	@Value("40")
	private int empsAge;
	
	@Autowired
	private SBUAnno addSbu;
	public SBUAnno getAddSbu() {
		return addSbu;
	}
	
	@Override
	public String toString() {
		return "Employees [Employee Id=" + empsId + ", Employee Name=" + empsName + ",Employee Sal=" + empsSal + ",Employee Age="
				+ empsAge + ", addSbu=" + addSbu + "]";
	}

	public int getEmpsAge() {
		return empsAge;
	}

	public void setEmpsAge(int empsAge) {
		this.empsAge = empsAge;
	}

	public void setAddSbu(SBUAnno addSbu) {
		this.addSbu = addSbu;
	}
	public int getEmpsId() {
		return empsId;
	}
	public void setEmpsId(int empsId) {
		this.empsId = empsId;
	}
	public String getEmpsName() {
		return empsName;
	}
	public void setEmpsName(String empsName) {
		this.empsName = empsName;
	}
	public double getEmpsSal() {
		return empsSal;
	}
	public void setEmpsSal(double empsSal) {
		this.empsSal = empsSal;
	}
	public EmployeeAnno() {
		super();
	}

}
