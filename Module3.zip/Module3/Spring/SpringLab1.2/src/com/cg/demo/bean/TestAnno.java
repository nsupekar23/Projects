package com.cg.demo.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestAnno {

	public static void main(String[] args) {
		ApplicationContext ctx=new
				ClassPathXmlApplicationContext("cg.xml");
		EmployeeAnno e1=(EmployeeAnno)ctx.getBean("emp1");
		System.out.println(e1);
		EmployeeAnno e2=(EmployeeAnno)ctx.getBean("emp2");
		System.out.println(e2);
	}

}
