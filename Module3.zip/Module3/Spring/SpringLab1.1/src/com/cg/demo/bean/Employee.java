package com.cg.demo.bean;

import java.time.LocalDate;
import java.util.ArrayList;

public class Employee {
	
	private int empId;
	private String empname;
	private double empSal;
	private String bUnit;
	private int empAge;
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpname() {
		return empname;
	}
	public void setEmpname(String empname) {
		this.empname = empname;
	}
	public double getEmpSal() {
		return empSal;
	}
	public void setEmpSal(double empSal) {
		this.empSal = empSal;
	}
	public String getbUnit() {
		return bUnit;
	}
	public void setbUnit(String bUnit) {
		this.bUnit = bUnit;
	}
	public int getEmpAge() {
		return empAge;
	}
	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}
	@Override
	public String toString() {
		return "Employee Details: \n-------------------------------\nEmployee ID:" + empId + "\nEmployee Name: " + empname + "\nEmployee Salary: " + empSal + "\nEmployee BU: " + bUnit
				+ "\nEmployee Age: " + empAge ;
	}
	public Employee() {
		super();
	}
	
	

}