package com.cg.demo.bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class TestEmpClient 
{

	public static void main(String[] args)
	{
		ApplicationContext ctx=new
				ClassPathXmlApplicationContext("cg.xml");
		Employee e1=(Employee)ctx.getBean("emp1");
		System.out.println(e1);

	}
}
