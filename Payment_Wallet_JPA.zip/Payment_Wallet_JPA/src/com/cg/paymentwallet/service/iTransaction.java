package com.cg.paymentwallet.service;

import java.util.ArrayList;
import java.util.List;

import com.cg.paymentwallet.bean.Transaction;
import com.cg.paymentwallet.exception.CustomerException;

public interface iTransaction {
	public Transaction addtransaction(Transaction tran) throws CustomerException;
	public ArrayList<Transaction> gettransaction(long acno ) throws CustomerException;
}
