package com.cg.paymentwallet.dao;


import java.util.ArrayList;


import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.paymentwallet.bean.Customer;
import com.cg.paymentwallet.bean.Transaction;
import com.cg.paymentwallet.exception.CustomerException;
import com.cg.paymentwallet.util.JPAUtil;


public class TransactionDAOImpl implements iTransactionDAO {
	EntityManager em = null;
	EntityTransaction trans=null;
	
	public TransactionDAOImpl(){
		em = JPAUtil.getEntityManager();
		trans = em.getTransaction();
		
	}

	@Override
	public Transaction addtransaction(Transaction tran) throws CustomerException {
	//
		trans.begin();
		em.persist(tran);
		trans.commit();
		return tran;
	}

	@Override
	public ArrayList<Transaction> gettransaction(long acno) throws CustomerException {

		TypedQuery query = em.createQuery("Select trans from Transaction trans where acno="+acno,Transaction.class);
		ArrayList cusList =(ArrayList) query.getResultList();
		return cusList;

	}

}