package com.cg.paymentwallet.dao;


import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityTransaction;
import javax.persistence.TypedQuery;

import com.cg.paymentwallet.bean.Customer;
import com.cg.paymentwallet.exception.CustomerException;
import com.cg.paymentwallet.util.JPAUtil;

public class CustomerDAOImpl implements iCustomerDAO {

	EntityManager em = null;
	EntityTransaction tran=null;

	public CustomerDAOImpl() {
		
		em = JPAUtil.getEntityManager();
		tran = em.getTransaction();

	}

	@Override
	public Customer createAccount(Customer cust) throws CustomerException {
		
		tran.begin();
		em.persist(cust);
		tran.commit();
		System.out.println("Account Created");
	
		return cust;

	}

	@Override
	public Customer AddMoney(long acc, int pin, double balance) throws CustomerException {
		
		Customer cust1= em.find(Customer.class, acc);
		
		double currentbalance= cust1.getBalance();
		double totalbalance=currentbalance+balance;
		cust1.setBalance(totalbalance);
		tran.begin();
		em.persist(cust1);
		tran.commit();
		
		return cust1;
	}

	@Override
	public Customer TransferMoney(long acc, long acc1, double balance) throws CustomerException {
		Customer cust= em.find(Customer.class, acc);
		Customer cust1= em.find(Customer.class, acc1);
		
		if(cust.getBalance()>balance) 
		{
			double accbalance = cust.getBalance()-balance;
			cust.setBalance(accbalance);
			tran.begin();
			em.persist(cust);
			tran.commit();
			
			double acc1balance= cust1.getBalance()+balance;
			cust1.setBalance(acc1balance);
			tran.begin();
			em.persist(cust1);
			tran.commit();
			
		}
		else {
			
			System.out.println("Enter Valid amount..!!");
		}
				
		return cust1;
	}

	@Override
	public ArrayList<Customer> getAccountList() throws CustomerException {
		
		
		
		TypedQuery query = em.createQuery("Select cust from Customer cust",Customer.class);
		ArrayList cusList =(ArrayList) query.getResultList();
		return cusList;
		
	}

	@Override
	public Customer getAccount(long acc) throws CustomerException {
		Customer cust= em.find(Customer.class, acc);
		return cust;
	}

	@Override
	public Customer withdraw(long acc, double amount) throws CustomerException {
		
		Customer wid= em.find(Customer.class, acc);
		
		double balance= wid.getBalance();
		double avlbalance=balance-amount;
		wid.setBalance(avlbalance);
		tran.begin();
		em.persist(wid);
		tran.commit();
		return wid;
		
	}

}
