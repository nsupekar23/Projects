package MobilePurchaseSystemNew;

public @interface BeforeClass {

}
