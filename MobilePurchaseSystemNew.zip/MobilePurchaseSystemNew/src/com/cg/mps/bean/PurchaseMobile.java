package com.cg.mps.bean;

public class PurchaseMobile {
	private String purchaseId;
	private String mobileId;
	private String customerName;
	private String customerNumber;
	private String customerEmail;
	
	
	public PurchaseMobile(){	
	}
	

	public PurchaseMobile(String purchaseId, String mobileId, String customerName,
			String customerNumber, String customerEmail) {
		super();
		this.purchaseId = purchaseId;
		this.mobileId = mobileId;
		this.customerName = customerName;
		this.customerNumber = customerNumber;
		this.customerEmail = customerEmail;
	}

	

	public String getPurchaseId() {
		return purchaseId;
	}

	public void setPurchaseId(String purchaseId) {
		this.purchaseId = purchaseId;
	}

	public String getMobileId() {
		return mobileId;
	}

	public void setMobileId(String mobileId) {
		this.mobileId = mobileId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerNumber() {
		return customerNumber;
	}

	public void setCustomerNumber(String customerNumber) {
		this.customerNumber = customerNumber;
	}

	public String getCustomerEmail() {
		return customerEmail;
	}

	public void setCustomerEmail(String customerEmail) {
		this.customerEmail = customerEmail;
	}

	@Override
	public String toString() {
		return "PurchaseMobile [purchaseId=" + purchaseId + ", mobileId="
				+ mobileId + ", customerName=" + customerName
				+ ", customerNumber=" + customerNumber + ", customerEmail="
				+ customerEmail + "]";
	}
	
		
}
