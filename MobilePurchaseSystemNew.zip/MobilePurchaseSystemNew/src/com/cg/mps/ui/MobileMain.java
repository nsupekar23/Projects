package com.cg.mps.ui;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mps.bean.Mobile;
import com.cg.mps.bean.PurchaseMobile;
import com.cg.mps.dao.MobileDao;
import com.cg.mps.dao.MobileDaoImpl;
import com.cg.mps.exception.MobileDBException;
import com.cg.mps.service.MobileServiceImpl;


public class MobileMain {

	static Logger logger=Logger.getRootLogger();

	public static void main(String[] args) throws MobileDBException
	{
		PropertyConfigurator.configure("Resource/log4j.properties");
		
		MobileServiceImpl mosrImpl = new MobileServiceImpl();
		Scanner sc = new Scanner(System.in);
		do {
			System.out.println("Menu");
			System.out.println("1. Enter new mobile to be added");
			System.out.println("2. Order mobile");
			System.out.println("3. Display all mobiles");
			System.out.println("4. Remove Mobile ");
			System.out.println("5. Search for  mobile");
			System.out.println("6. Search mobile in price range");
			System.out.println("5. Exit\n");
			System.out.println(" Enter your choice\n");
			String choice = sc.next();

			switch (choice) {
			case "1":
				System.out.println("Please enter Mobile Name you want to add");
				String mname = sc.next();
				System.out.println("Enter mobile price");
				String price = sc.next();
				System.out.println("Enter quantity");
				String quantity = sc.next();
				Mobile mobile = new Mobile(null, mname, price,quantity);
				try {
					if (mosrImpl.isValidMobile(mobile)) {
					String mid = mosrImpl.addMobile(mobile);
						System.out.println("Mobile inserted in table with id "+mid);
					}
				} catch (MobileDBException e) {
					logger.error("Mobilename can't be generated ");
					System.out.println(e.getMessage());
				}/*catch(MobileDBException e){
					System.out.println(e.getMessage());
				}*/
				break;
			case "2":
				System.out.println("Please enter mobile id to purchase");
				System.out.println("*Note : Mobile id is started from 1000");
				String mid = sc.next();
				System.out.println("Enter customer name");
				String cname = sc.next();
				System.out.println("Enter emailid");
				String email = sc.next();
				System.out.println("Enter phone number");
				String phone = sc.next();
				//String moid = null;
				PurchaseMobile purchaseMobile = new PurchaseMobile(null,mid,cname,email,phone);
				try{
					if(mosrImpl.searchMobile(mid) == null){
						System.out.println("Mobile not available with id"+ mid);
					}
					else
					{
						if(mosrImpl.isValidPurchaseMobile(purchaseMobile)){
							mosrImpl.purchaseMobile(purchaseMobile);
							System.out.println("Purchase done with id " + purchaseMobile.getPurchaseId());
						}
					}
				}catch(MobileDBException e){
					logger.error("PurchaseId can't be generated ");
				
					System.out.println(e.getMessage());
				} 
				/*catch (MobileDBException e) {
					System.out.println(e.getMessage());
				}*/
				break;
			case "3":
				try {
					List<Mobile> mlist = mosrImpl.getAllMobiles() ;
					if (mlist.size() == 0) {
						System.out.println("No mobile available");
					} else {
						for (Mobile m : mlist) {
							System.out.println(m);
						}
					}
				} catch (MobileDBException e) {
					logger.error("Mobile not available ");
					
					System.out.println(e.getMessage());
				}
				break;
				
			case "4":
				System.out.println("Please enter mobile id you want to delete");
				System.out.println(" Kindly Note : Mobile id is started from 1000");
				String mobid = sc.next();
				try {
					if(mosrImpl.searchMobile(mobid) == null){
						System.out.println("Mobile doesn't exist with product id" + mobid);
					}else{
						mosrImpl.deleteMobile(mobid);
						System.out.println("Mobile deleted with mobile id " + mobid);
					}
				} catch (MobileDBException e) {
					System.out.println(e.getMessage());
				} 
				break;
				
			case "5":
				System.out.println("Please enter mobile id you want to search");
				System.out.println("Kindly Note : Mobile id is started from 1000");
				String mobileid = sc.next();
				try{
					System.out.println("Search result is:");
					mosrImpl.searchMobile(mobileid);
					System.out.println(mobileid);
					
				}catch(MobileDBException e){
					logger.error("MobileId can't be generated ");
					System.out.println(e.getMessage());
				}
				break;
				
			case "6":
				System.exit(0);
				break;
			default:
				System.out.println("Choise is Invalid !!! Please try again");
				break;
			}
		} while (true);
	}
}
