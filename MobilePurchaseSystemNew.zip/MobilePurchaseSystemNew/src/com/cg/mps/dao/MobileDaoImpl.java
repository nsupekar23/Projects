package com.cg.mps.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.mps.bean.Mobile;
import com.cg.mps.bean.PurchaseMobile;
import com.cg.mps.exception.MobileDBException;
import com.cg.mps.util.DBUtil;

public class MobileDaoImpl implements MobileDao {
	
	Logger logger=Logger.getRootLogger();
	
	Connection conn = null;
	public MobileDaoImpl()
	{
	
	
	}
	@Override
	public String addMobile(Mobile mobile) throws MobileDBException {
		
		mobile.setMobileId(generateMobileId());
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(QueryMapper.INSERT_MOBILE_QUERY);
			pst.setString(1, mobile.getMobileId());
			pst.setString(2, mobile.getMobileName());
			pst.setString(3, mobile.getMobilePrice());
			pst.setString(4, mobile.getQuantity());
			pst.executeUpdate();
		} catch (SQLException e) {
			logger.error("Database cant be connected ");
			throw new MobileDBException("Problem in inserting product details"+e.getMessage());
		}
		
		return mobile.getMobileId();
	}
	private String generateMobileId() throws MobileDBException{
		String mid = null;

		conn = DBUtil.getConnection();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rst  = stmt.executeQuery(QueryMapper.MOBILEID_SEQUENCE_QUERY);
			while(rst.next()){
				mid = rst.getString(1);
			}
			
		} catch (SQLException e) {
			logger.error("MobileId can't be generated ");
			throw new MobileDBException("Problem in generating mobile id");
		}
		return mid;
	}
	@Override
	public List<Mobile> getAllMobiles() throws MobileDBException {
		List<Mobile> mobileList = new ArrayList<Mobile>();
		conn = DBUtil.getConnection();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rst = stmt.executeQuery(QueryMapper.RETRIVE_ALL_MOBILES_QUERY);
			while (rst.next()) {
				Mobile mob = new Mobile();
				mob.setMobileId(rst.getString("mobileid"));
				mob.setMobileName(rst.getString("name"));
				mob.setMobilePrice(rst.getString("price"));
				mob.setQuantity(rst.getString("quantiooty"));
				mobileList.add(mob);
			}
		} catch (SQLException e) {
			logger.error("MobileId can't be generated ");
			throw new MobileDBException("Problem in fetching mobile list"+e.getMessage());
		}
		return mobileList;
	}

	@Override
	public String purchaseMobile(PurchaseMobile purchaseMobile) throws MobileDBException {
		purchaseMobile.setPurchaseId(generatePurchaseId());
		conn = DBUtil.getConnection();
		try {
			PreparedStatement purchasePst = conn.prepareStatement(QueryMapper.INSERT_PURCHASE_QUERY);
			purchasePst.setString(1, purchaseMobile.getPurchaseId());
			purchasePst.setString(2, purchaseMobile.getCustomerName());
			purchasePst.setString(3, purchaseMobile.getCustomerEmail());
			purchasePst.setString(4, purchaseMobile.getCustomerNumber());
			purchasePst.setString(5, purchaseMobile.getMobileId());
			purchasePst.executeQuery();
			
			PreparedStatement mobilePst = conn.prepareStatement(QueryMapper.MOBILE_UPDATE_QUERY);
			mobilePst.setString(1, purchaseMobile.getMobileId());
			mobilePst.executeQuery();
		} catch (SQLException e) {
			logger.error("Order can't be placed ");
			throw new MobileDBException("Problem in placing order "+e.getMessage());
		}
		return purchaseMobile.getPurchaseId();
	}
	
	
	private String generatePurchaseId() throws MobileDBException{
		String pid = null;
		conn = DBUtil.getConnection();
		try {
			Statement stmt = conn.createStatement();
			ResultSet rst  = stmt.executeQuery(QueryMapper.PURCHASEID_SEQUENCE_QUERY);
			rst.next();
			pid = rst.getString(1);
			
		} catch (SQLException e) {
			logger.error("PurchaseId can't be generated ");
			throw new MobileDBException("Problem in generating purchase id" + e.getMessage());
		}
		return pid;
	}
	
	@Override
	public String deleteMobile(String mobileId) throws MobileDBException {
		conn = DBUtil.getConnection();
		try{
			PreparedStatement pst = conn.prepareStatement(QueryMapper.MOBILE_DELETE_QUERY);
			pst.setString(1,mobileId);
			pst.executeUpdate();
		}catch(SQLException e){
			logger.error("Mobile cant be deleted ");
			System.out.println("Problem in deleting mobile" + e.getMessage());
		}
		return mobileId;
	}

	@Override
	public Mobile searchMobileInPriceRange(Mobile mobile)
			throws MobileDBException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Mobile searchMobile(String mobileId) throws MobileDBException {
		String sql = "SELECT mobileid, name, price, quantity from mobiles1 WHERE mobileid=?";
		Mobile mob = null;
		conn = DBUtil.getConnection();
		try {
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, mobileId);
			ResultSet rst = pst.executeQuery();
			if(rst.next()){
				mob = new Mobile();
				mob.setMobileId(rst.getString("mobileid"));
				mob.setMobileName(rst.getString("name"));
				mob.setMobilePrice(rst.getString("price"));
				mob.setQuantity(rst.getString("quantity"));
			}
		} catch (SQLException e) {
			logger.error("MobileId can't be searched ");
			throw new MobileDBException("Problem in searching mobile"+e.getMessage());
		}
		return mob;
	}

}
