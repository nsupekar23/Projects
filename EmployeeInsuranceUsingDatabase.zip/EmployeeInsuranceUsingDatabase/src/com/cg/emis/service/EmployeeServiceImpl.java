package com.cg.emis.service;

import java.util.ArrayList;

import com.cg.emis.bean.Employee;
import com.cg.emis.dao.EmployeeDAO;
import com.cg.emis.dao.EmployeeDAOImpl;
import com.cg.emis.exception.EmployeeException;

public class EmployeeServiceImpl  implements EmployeeService{

	EmployeeDAO dao;

	public EmployeeServiceImpl() {
		dao= new EmployeeDAOImpl();
	}
	
	@Override
	public Employee AddEmployee(Employee emp) throws EmployeeException {
	
		emp=dao.AddEmployee(emp);
		return emp;
	}

	@Override
	public ArrayList<Employee> getEmployeeList() throws EmployeeException {
		return dao.getEmployeeList();
	}

	@Override
	public Employee updateInsuranceScheme(int id) throws EmployeeException {
		Employee emp= dao.updateInsuranceScheme(id);
		return emp;
	}

	@Override
	public Employee deleteEmployee(int empid) throws EmployeeException {
		Employee emp= dao.deleteEmployee(empid);
		if(emp== null)
			throw new EmployeeException("Empid does not exist");
		else
			return emp;
	}
	

}
