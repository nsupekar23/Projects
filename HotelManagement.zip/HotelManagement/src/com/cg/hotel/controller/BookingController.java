package com.cg.hotel.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.hotel.dto.Hotel;
import com.cg.hotel.service.IBookingService;



@Controller
@RequestMapping(value = "/showHotel")
public class BookingController {
	@Autowired
	IBookingService service = null;

	public IBookingService getService() {
		return service;
	}

	public void setService(IBookingService service) {
		this.service = service;
	}

	@RequestMapping(value = "/hotelList")
	public String showHotelList(Model model) {
		ArrayList<Hotel> hlist = service.fetchAll();
		model.addAttribute("hotel", hlist);
		return "HotelList";
	}
	
	
	@RequestMapping(value = "/display",method=RequestMethod.GET)
	public String showHotelName(@RequestParam("msg") String name,Model model) {
	String msg ="your rooms are booked at "+name+"";
	System.out.println(msg);
	model.addAttribute("msgObj",msg);	
	return "HotelBooking";
	}

}
