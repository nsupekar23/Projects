package com.cg.hotel.service;

import java.util.ArrayList;

import com.cg.hotel.dto.Hotel;



public interface IBookingService {
	public ArrayList<Hotel> fetchAll();
}
