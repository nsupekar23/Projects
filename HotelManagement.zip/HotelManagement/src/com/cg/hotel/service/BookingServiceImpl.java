package com.cg.hotel.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hotel.dao.IBookingDAO;
import com.cg.hotel.dto.Hotel;

@Service
public class BookingServiceImpl implements IBookingService {

	@Autowired
	IBookingDAO dao = null;

	public IBookingDAO getDao() {
		return dao;
	}

	public void setDao(IBookingDAO dao) {
		this.dao = dao;
	}

	@Override
	public ArrayList<Hotel> fetchAll() {
		// TODO Auto-generated method stub
		return dao.fetchAll();
	}

}
