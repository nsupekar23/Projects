package com.cg.hotel.dao;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;

import com.cg.hotel.dto.Hotel;

@Repository
public class BookingDAOImpl implements IBookingDAO {

	@PersistenceContext
	EntityManager entityMgr = null;

	public EntityManager getEntityMgr() {
		return entityMgr;
	}

	public void setEntityMgr(EntityManager entityMgr) {
		this.entityMgr = entityMgr;
	}

	@Override
	public ArrayList<Hotel> fetchAll() {
		String sql1 = "SELECT tr FROM Hotel tr ";

		TypedQuery<Hotel> ht = entityMgr.createQuery(sql1, Hotel.class);
		ArrayList<Hotel> hlist = (ArrayList) ht.getResultList();
		return hlist;
	}

}
