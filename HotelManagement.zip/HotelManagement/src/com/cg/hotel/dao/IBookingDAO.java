package com.cg.hotel.dao;

import java.util.ArrayList;

import com.cg.hotel.dto.Hotel;

public interface IBookingDAO {
	public ArrayList<Hotel> fetchAll();
}
